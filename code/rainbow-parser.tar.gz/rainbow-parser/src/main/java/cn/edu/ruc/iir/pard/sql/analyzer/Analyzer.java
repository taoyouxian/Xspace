package cn.edu.ruc.iir.pard.sql.analyzer;

/**
 * pard
 *
 * @author guodong
 */
public class Analyzer
{
}
